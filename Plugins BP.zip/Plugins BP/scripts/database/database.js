import{world,system}from'@minecraft/server';
const overworld = world.getDimension("overworld");
export class Database {
    constructor(databaseName) {
        this.databaseName = databaseName;
        this.objective = world.scoreboard.getObjective(databaseName) ?? world.scoreboard.addObjective(databaseName, databaseName);
        this.data = JSON.parse(`{${this.objective.getParticipants().map(e => e.displayName.replace(/\\"/g, '"')).join(",")}}`);
        this.modified = false;
        this.proxy = this.createProxy(this.data);
    }

    createProxy(target) {
        return new Proxy(target, {
            get: (target, key) => (Array.isArray(target[key]) ? this.createProxy(target[key]) : target[key]),
            set: (target, key, value) => {
                target[key] = value;
                this.handleModification();
                return true;
            },
            deleteProperty: (target, key) => {
                delete target[key];
                this.handleModification();
                return true;
            },
            has: (target, key) => key in target,
            ownKeys: target => Reflect.ownKeys(target),
        });
    }

    get all() {
        return this.proxy;
    }

    handleModification() {
        if (!this.modified) {
            this.modified = true;
            system.run(() => {
                this.save();
                this.modified = false;
            });
        }
    }

    save() {
        try {
            world.scoreboard.removeObjective(this.databaseName);
        } catch {}
        world.scoreboard.addObjective(this.databaseName, this.databaseName);
        for (const key in this.data) {
            const value = JSON.stringify(this.data[key]).replace(/"/g, '\\"');
            overworld.runCommandAsync(`scoreboard players set "\\"${key}\\":${value}" ${this.databaseName} 0`);
        }
    }
}