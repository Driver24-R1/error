import{ActionFormData,MessageFormData,ModalFormData}from"@minecraft/server-ui";//creador de UI
import {world,system,EntitySpawnAfterEvent,Player,EntityEquippableComponent,EquipmentSlot} from"@minecraft/server";//adminitrador del codigo
import { Database } from "../../database/database";//base de datos

const DataBan = new Database("databan");
const currentDate = new Date();
const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}/${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getFullYear().toString().slice(-2)}`;

world.afterEvents.entityHitEntity.subscribe(({ damagingEntity: player, hitEntity: entity }) => {
  if (entity instanceof Player)
  if (player.getComponent(EntityEquippableComponent.componentId).getEquipment(EquipmentSlot.Mainhand)?.typeId === 'minecraft:barrier') {
    UIBan(player, entity)
  }
})
world.afterEvents.itemUse.subscribe(({ source: player, itemStack: item }) => {
  switch (item.typeId) {
    case "minecraft:clock": 
    UIBaneos(player)
      break;
  }
})

system.runInterval(() => {
  const datos = Object.keys(DataBan.all); // Obtener las claves de los baneados
  
  for (const player of world.getPlayers()) {
    for (const InfoData of datos) {
      const { diaban, diadesban, razon, name } = DataBan.all[InfoData];

      // Asegúrate de que formattedDate está definido antes de usarlo
      if (typeof formattedDate === "undefined") {
        console.warn("Error: formattedDate no está definido.");
        return;
      }

      // Si la fecha actual coincide con la de desbaneo, eliminar el baneo
      if (formattedDate === diadesban) {
        delete DataBan.all[InfoData];
        console.warn(`Jugador ${name} desbaneado exitosamente.`);
      } else if (player.name === InfoData) {
        const msg = `§eSuspensión Temporal\n§cJugador: ${player.name}\n§aBaneo: ${diaban}\n§cDesbaneo: ${diadesban}\n§eRazón: ${razon}`;
        player.runCommand(`kick ${player.name} ${msg}`);
        console.warn(`Jugador ${name} expulsado correctamente.`);
      }
    }
  }
});



const UIBan = (player, entity) => {
  const form = new ModalFormData()
    .title("Ban")
    .textField(
      `Hola ${player.name}, vas a banear a ${entity.name}.\n\nInformacion:\n-Nombre: ${entity.name}.\n-Fecha de baneo: ${formattedDate}\n\n§i>> Días de baneo`,
      "30"
    )
    .textField("\n§l§i>> Razón del baneo", "Por gay");

  form.show(player).then(({ formValues, canceled }) => {
    if (canceled) return; // Si el jugador cancela, no hacer nada

    let dias = formValues[0] ? convertirNumero(formValues[0]) : 30; // Si no ingresa días, usa 30
    let razon = formValues[1] || "Sin razón especificada"; // Si no ingresa razón, usa un valor por defecto

    if (isNaN(dias) || dias <= 0) {
      player.sendMessage("§cError: Ingresa un número válido de días.");
      return;
    }

    const fechaDesbaneo = sumarDias(formattedDate, dias); // Calcula la fecha de desbaneo

    const msg = `§eSuspensión Temporal\n§cJugador: ${entity.name}\n§aBaneo: ${formattedDate}\n§cDesbaneo: ${fechaDesbaneo}\n§eRazón: ${razon}`;
    
    const data = {
      diaban: formattedDate,
      diadesban: fechaDesbaneo,
      razon: razon,
      name: player.name,
    };

    DataBan.all[entity.name] = data; // Guarda la información en la base de datos

    entity.runCommand(`kick "${entity.name}" "${msg}"`); // Ejecuta el kick correctamente
  });
};
const UIBaneos = (player) => {
  const form = new ActionFormData()
    .title("Lista de Baneos")
    .body("Seleccione una acción\n\nNo utilizar la opción 'Lista' si hay un montón de personas baneadas.")
    .button("Buscar")
    .button("Lista");

  form.show(player).then(({ selection, canceled }) => {
    if (canceled) return; // Si se cancela el formulario, no hacer nada

    // Verificar si hay baneos registrados
    const cantidadBaneados = Object.keys(DataBan.all).length;

    if (cantidadBaneados === 0) {
      player.sendMessage("No hay información de baneos.");
      return;
    }

    if (selection === 1) {
      UILista(player); // Muestra la lista de baneos
    } else if (selection === 0) {
      UIBuscar(player); // Muestra el buscador de baneos
    }
  });
};
const UILista = (player) => {
  const datos = Object.keys(DataBan.all);
  const form = new ActionFormData()
  .title("Lista")
  for (const InfoData of datos) {
    form.button(InfoData)
  }
  form.show(player).then(({selection,canceled})=>{
    const InfoData = datos[selection];
    UIInfo(player, InfoData)
    
  })
};
const UIInfo = (player, data) => {
  const InfoData = DataBan.all[data];  // Obtener los datos del jugador
  const { diaban, diadesban, razon, name } = InfoData;  // Desestructuración del objeto InfoData

  // Crear el formulario con la información correcta
  const form = new ActionFormData()
    .title(`Información de ${data}`)
    .body(`Información de ${data}\n\n- Nombre: ${data}\n- Fecha de baneo: ${diaban}\n- Fecha de desbaneo: ${diadesban}\n- Responsable del baneo: ${name}\n- Razón: ${razon}`)
    .button("Eliminar Baneo");

  // Mostrar el formulario y manejar la selección
  form.show(player).then(({ selection, canceled }) => {
    if (canceled) return;  // Si el formulario se cancela, no hacer nada
    if (selection === 0) {
      // Eliminar el baneo
      delete DataBan.all[data];  // Eliminar la información del jugador baneado
      player.sendMessage("§aJugador desbaneado exitosamente");
    }
  });
};
const UIBuscar = (player) => {
  const listaName = Object.keys(DataBan.all);
  const form = new ModalFormData()
    .title("Buscador")
    .textField(`Busca el jugador\n§l§i>> Nombre a buscar`, "Gay");

  form.show(player).then(({ formValues, canceled }) => {
    if (canceled) return;
    const name = formValues[0];
    const resultados = buscarPersonas(name, listaName);

    if (resultados.length === 0) {
      const form0 = new ActionFormData()
        .title("Búsqueda")
        .body("No se encontraron jugadores.")
        .button("Cerrar");

      return form0.show(player);
    }
    const form0 = new ActionFormData().title("Resultados de búsqueda");

    resultados.forEach(nombre => {
      form0.button(nombre);
    });
    form0.button("Cerrar");
    form0.show(player).then(({ selection, canceled }) => {
      if (canceled || selection === resultados.length) return;

      let name = resultados[selection]; 
      UIInfo(player, name)
    });
  });
};

function convertirNumero(diaTexto) {
  return parseInt(diaTexto, 10); // Convierte el texto a número
}
function buscarPersonas(termino, listaPersonas) {
  termino = termino.toLowerCase(); // Convertir el término a minúsculas para búsqueda flexible
  return listaPersonas.filter(persona => persona.toLowerCase().includes(termino));
}
function sumarDias(fecha, dias) {
  let partes = fecha.split("/"); // Dividir la fecha en día, mes y año
  let fechaObj = new Date(`20${partes[2]}`, partes[1] - 1, partes[0]); // Crear objeto Date
  fechaObj.setDate(fechaObj.getDate() + dias); // Sumar días

  let dia = fechaObj.getDate().toString().padStart(2, "0");
  let mes = (fechaObj.getMonth() + 1).toString().padStart(2, "0");
  let año = fechaObj.getFullYear().toString().slice(2); // Obtener solo los últimos dos dígitos del año

  return `${dia}/${mes}/${año}`;
}

