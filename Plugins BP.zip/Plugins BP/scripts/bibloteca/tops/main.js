import{ActionFormData,MessageFormData,ModalFormData}from"@minecraft/server-ui";//creador de UI
import { world, system } from '@minecraft/server';
import { Database } from '../../database/database';

const Tops = new Database("Tops");

world.afterEvents.itemUse.subscribe(({ source: player, itemStack: item }) => {
  switch (item.typeId) {
    case "minecraft:bedrock": 
    UITops(player)
      break;
  }
})

const UITops = (player) => {
  const form = new ActionFormData()
  .title("Create Tops")
  .body("Seleccione una accion")
  .button("Crea")
  .button("Eliminar")
  form.show(player).then(({ selection, canceled }) => {
    if (selection === 0) {
      UICrea(player)
    }
  })
}
const UICrea = (player) => {
  const form = new ModalFormData()
  .title("Tops")
  .textField(`Estas a punto de crear un tops\n\n>> Nombre del Tops_`, 'gg')
  .textField(`\n>> Scorebuard:`, 'coins')
  form.show(player).then(({ formValues,canceled }) => {
    const name = formValues[0];
    const score = formValues[1];
    const loc = player.location;
    const entity = player.dimension.spawnEntity('floating:text', { x: loc.x, y: loc.y, z: loc.z });
    
    entity.nameTag = name || "Error"
    entity.addTag(name)

    const scoreboard = world.scoreboard;
    if (!scoreboard.getObjective(score)) {
      scoreboard.addObjective(score);
      console.warn(`Objetivo '${score}' agregado al marcador.`);
    } else {
      console.warn(`El objetivo '${score}' ya existe.`);
    }
  

    const data = {
      score: score,
      top: []
    }
    Tops.all[name] = data;
  })
}

system.runInterval(() => {
  const datos = Object.keys(Tops.all);

  for (const player of world.getPlayers()) {
    for (const InfoData of datos) {
      const { score, top = [] } = Tops.all[InfoData]; // Asegura que `top` no sea undefined
      const scores = getScore(player, score);

      if (scores > 0) { // Solo guarda si el puntaje es mayor a 0
        // Buscar si el jugador ya está en la lista y actualizar su puntaje
        const index = top.findIndex(entry => entry.name === player.name);
        if (index !== -1) {
          top[index].score = scores; // Actualiza el puntaje
        } else {
          top.push({ name: player.name, score: scores }); // Agrega si no está en la lista
        }
      } else {
        // Eliminar al jugador si su puntaje es 0 o menor
        const index = top.findIndex(entry => entry.name === player.name);
        if (index !== -1) {
          top.splice(index, 1);
        }
      }

      // Ordenar y mantener solo los 10 mejores
      top.sort((a, b) => b.score - a.score);
      const top10 = top.slice(0, 10);

      // Actualiza la entrada en `Tops.all`
      Tops.all[InfoData] = { score, top: top10 };
    }
  }
});
system.runInterval(() => {
  const datos = Object.keys(Tops.all);
  const entities = world.getDimension("overworld").getEntities({ type: 'floating:text' });

  for (const entity of entities) {
    for (const InfoData of datos) {
      const { top = [] } = Tops.all[InfoData];

      if (entity.hasTag(`${InfoData}`)) {
        // Ordenar el top de mayor a menor
        top.sort((a, b) => b.score - a.score);

        // Limitar el top a 10 jugadores
        const top10 = top.slice(0, 10);

        // Crear el texto del top
        let text = `§l§6Top ${InfoData}:\n`;
        top10.forEach((entry, index) => {
          text += `§e${index + 1}. §b${entry.name} §7- §a${entry.score}\n`;
        });

        // Aplicar el texto a la entidad flotante
        entity.nameTag = text.trim();
      }
    }
  }
});


function getScore(target, objective) {
  try {
    const oB = world.scoreboard.getObjective(objective);
    return oB ? oB.getScore(typeof target === 'string' ? oB.getParticipants().find(pT => pT.displayName == target) : target.scoreboardIdentity) : 0;
  } catch {
    return 0;
  }
}




