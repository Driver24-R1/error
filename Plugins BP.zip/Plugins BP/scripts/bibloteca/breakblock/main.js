import { world, system } from "@minecraft/server";

world.afterEvents.playerBreakBlock.subscribe(({ block, player }) => {
  const loc = block.location;// la ubicacion del bloque
  const items = player.dimension.getEntities({ location: loc, maxDistance: 1.5 });// hacemos el bloque una entidad
  
  //proceso para octener el bloque
  items.filter(itemEntity => itemEntity.typeId === "minecraft:item").forEach(itemEntity => {
    const item = itemEntity.getComponent("item").itemStack;
    const inventory = player.getComponent("inventory").container;
    const remaining = inventory.addItem(item);
    itemEntity.remove();
    if (remaining) player.dimension.spawnItem(remaining, loc);
  })
});

//Player, EntityEquippableComponent, EquipmentSlot, EntityInventoryComponent, ItemStack, ItemTypes